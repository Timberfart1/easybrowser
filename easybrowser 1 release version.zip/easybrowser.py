from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtPrintSupport import *
import os
import sys

class Browser(QWebEngineView):
    def __init__(self):
        super().__init__()

        self.setUrl(QUrl("https://duckduckgo.com/"))
        self.setup_settings()
        self.setup_signals()

        # Handle full-screen toggle
        self.fullscreen_flag = False

    def setup_settings(self):
        """Enable settings for smoother performance"""
        settings = self.settings()
        settings.setAttribute(QWebEngineSettings.LocalStorageEnabled, True)
        settings.setAttribute(QWebEngineSettings.JavascriptEnabled, True)
        settings.setAttribute(QWebEngineSettings.PluginsEnabled, True)
        settings.setAttribute(QWebEngineSettings.WebGLEnabled, True)
        settings.setAttribute(QWebEngineSettings.AutoLoadImages, True)

    def setup_signals(self):
        """Connect signals for URL and page load status"""
        self.urlChanged.connect(self.update_urlbar)
        self.loadFinished.connect(self.update_title)

        # Add JavaScript callback to handle full-screen requests
        self.page().fullScreenRequested.connect(self.toggle_full_screen)

    def update_title(self):
        """Update window title with the current page title"""
        title = self.page().title()
        self.window().setWindowTitle(f"{title} - Easy Browser")

    def update_urlbar(self, q):
        """Update the URL bar with the current URL"""
        self.window().urlbar.setText(q.toString())
        self.window().urlbar.setCursorPosition(0)

    def toggle_full_screen(self, requested):
        """Toggle full-screen mode on/off for embedded content like YouTube"""
        if requested:
            if not self.fullscreen_flag:
                self.window().showFullScreen()  # Set the window to full-screen
                self.fullscreen_flag = True
            else:
                self.window().showNormal()  # Exit full-screen mode
                self.fullscreen_flag = False


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Set the main window properties
        self.setWindowTitle("Easy Browser")
        self.setGeometry(100, 100, 1200, 800)

        # Set up the tab widget
        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.add_new_tab()

        # Setup the status bar
        self.setup_status_bar()

        # Setup the toolbar
        self.setup_toolbar()

        # Download progress bar
        self.download_progress = QProgressBar(self)
        self.download_progress.setRange(0, 100)
        self.statusBar().addPermanentWidget(self.download_progress)

        self.download_history = []
        self.tabs.currentWidget().page().profile().downloadRequested.connect(self.on_download_requested)

        self.show()

    def setup_status_bar(self):
        """Set up the status bar"""
        self.status = QStatusBar()
        self.setStatusBar(self.status)

    def setup_toolbar(self):
        """Set up the toolbar with navigation actions"""
        navtb = QToolBar("Navigation")
        self.addToolBar(navtb)

        actions = [
            ("<--", "Back to previous page", self.tabs.currentWidget().back),
            ("-->", "Forward to next page", self.tabs.currentWidget().forward),
            ("Reload", "Reload page", self.tabs.currentWidget().reload),
            ("Home", "Go home", self.navigate_home),
            ("Stop", "Stop loading current page", self.tabs.currentWidget().stop),
            ("Downloads", "View past downloads", self.view_past_downloads),
            ("Fullscreen", "Toggle full screen", self.toggle_full_screen)
        ]
        for text, tip, action in actions:
            btn = QAction(text, self)
            btn.setStatusTip(tip)
            btn.triggered.connect(action)
            navtb.addAction(btn)

        navtb.addSeparator()

        # URL bar
        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)
        navtb.addWidget(self.urlbar)

        # Add "New Tab" action
        new_tab_action = QAction("New Tab", self)
        new_tab_action.triggered.connect(self.add_new_tab)
        navtb.addAction(new_tab_action)

        # Add Dark Mode Toggle
        dark_mode_action = QAction("Dark Mode", self, checkable=True)
        dark_mode_action.triggered.connect(self.toggle_dark_mode)
        navtb.addAction(dark_mode_action)

    def toggle_dark_mode(self, checked):
        """Switch between dark and light mode"""
        if checked:
            self.setStyleSheet("QMainWindow { background-color: #2e2e2e; color: white; }")
            self.tabs.setStyleSheet("QTabWidget::pane { background-color: #333; }")
        else:
            self.setStyleSheet("")
            self.tabs.setStyleSheet("")

    def toggle_full_screen(self):
        """Toggle full screen for the main window"""
        if self.isFullScreen():
            self.showNormal()  # Restore window size
        else:
            self.showFullScreen()  # Maximize the window to full screen

    def add_new_tab(self):
        """Add a new tab to the browser"""
        new_browser = Browser()
        self.tabs.addTab(new_browser, "New Tab")
        self.tabs.setCurrentWidget(new_browser)
        new_browser.page().profile().downloadRequested.connect(self.on_download_requested)

    def close_tab(self, index):
        """Close the selected tab"""
        widget = self.tabs.widget(index)
        if widget:
            widget.deleteLater()
        self.tabs.removeTab(index)

    def navigate_home(self):
        """Navigate to the homepage"""
        self.tabs.currentWidget().setUrl(QUrl("https://duckduckgo.com/"))

    def navigate_to_url(self):
        """Navigate to the URL in the URL bar"""
        q = QUrl(self.urlbar.text())
        if q.scheme() == "":
            q.setScheme("http")
        self.tabs.currentWidget().setUrl(q)

    def on_download_requested(self, download):
        """Handle download requests"""
        downloads_folder = QStandardPaths.writableLocation(QStandardPaths.DownloadLocation)
        file_name = download.url().fileName()
        download_path = os.path.join(downloads_folder, file_name)
        download.setPath(download_path)
        download.finished.connect(self.on_download_finished)
        download.downloadProgress.connect(self.on_download_progress)
        download.accept()

        # Save the download information to history
        self.download_history.append({'name': file_name, 'path': download_path, 'status': 'Downloading'})

    def on_download_progress(self, received, total):
        """Update the download progress bar"""
        if total > 0:
            progress = int((received / total) * 100)
            self.download_progress.setValue(progress)

    def on_download_finished(self):
        """Reset the progress bar once download is finished"""
        self.download_progress.reset()

    def view_past_downloads(self):
        """Show a dialog with past downloads"""
        dialog = QDialog(self)
        dialog.setWindowTitle("Past Downloads")
        layout = QVBoxLayout()

        download_table = QTableWidget(dialog)
        download_table.setColumnCount(4)
        download_table.setHorizontalHeaderLabels(['File Name', 'Path', 'Status', 'Actions'])
        download_table.setRowCount(len(self.download_history))

        for i, download in enumerate(self.download_history):
            download_table.setItem(i, 0, QTableWidgetItem(download['name']))
            download_table.setItem(i, 1, QTableWidgetItem(download['path']))
            download_table.setItem(i, 2, QTableWidgetItem(download['status']))

            open_button = QPushButton('Open')
            delete_button = QPushButton('Delete')
            open_button.clicked.connect(lambda _, path=download['path']: self.open_file(path))
            delete_button.clicked.connect(lambda _, index=i: self.delete_download(index, download_table))

            download_table.setCellWidget(i, 3, open_button)
            download_table.setCellWidget(i, 4, delete_button)

        layout.addWidget(download_table)
        dialog.setLayout(layout)
        dialog.exec_()

    def open_file(self, path):
        """Open the downloaded file"""
        if os.path.exists(path):
            os.startfile(path)

    def delete_download(self, index, table):
        """Remove a download from history and the table"""
        del self.download_history[index]
        table.removeRow(index)

# Creating the PyQt5 application
app = QApplication(sys.argv)
app.setApplicationName("Easy Browser")

# Creating the main window object
window = MainWindow()

# Start the application's event loop
sys.exit(app.exec_())
