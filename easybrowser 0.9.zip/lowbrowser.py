from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtPrintSupport import *
import os
import sys

class MainWindow(QMainWindow):
    def __init__(self, *args, **kwargs):
        super(MainWindow, self).__init__(*args, **kwargs)

        # creating a QWebEngineView
        self.browser = QWebEngineView()

        # setting default browser URL
        self.browser.setUrl(QUrl("https://duckduckgo.com/"))

        # Adding actions when URL changes or loading is finished
        self.browser.urlChanged.connect(self.update_urlbar)
        self.browser.loadFinished.connect(self.update_title)

        # set this browser as central widget or main window
        self.setCentralWidget(self.browser)

        # creating a status bar object
        self.status = QStatusBar()

        # adding status bar to the main window
        self.setStatusBar(self.status)

        # creating QToolBar for navigation
        navtb = QToolBar("Navigation")
        self.addToolBar(navtb)

        # adding actions to the tool bar
        back_btn = QAction("<--", self)
        back_btn.setStatusTip("Back to previous page")
        back_btn.triggered.connect(self.browser.back)
        navtb.addAction(back_btn)

        next_btn = QAction("-->", self)
        next_btn.setStatusTip("Forward to next page")
        next_btn.triggered.connect(self.browser.forward)
        navtb.addAction(next_btn)

        reload_btn = QAction("Reload", self)
        reload_btn.setStatusTip("Reload page")
        reload_btn.triggered.connect(self.browser.reload)
        navtb.addAction(reload_btn)

        home_btn = QAction("Home", self)
        home_btn.setStatusTip("Go home")
        home_btn.triggered.connect(self.navigate_home)
        navtb.addAction(home_btn)

        navtb.addSeparator()

        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)
        navtb.addWidget(self.urlbar)

        stop_btn = QAction("Stop", self)
        stop_btn.setStatusTip("Stop loading current page")
        stop_btn.triggered.connect(self.browser.stop)
        navtb.addAction(stop_btn)

        # Set up the download progress bar
        self.download_progress = QProgressBar(self)
        self.download_progress.setRange(0, 100)
        self.status.addPermanentWidget(self.download_progress)

        self.browser.page().profile().downloadRequested.connect(self.on_download_requested)

        # showing all the components
        self.show()

    def update_title(self):
        title = self.browser.page().title()
        self.setWindowTitle("% s - Low Browser" % title)

    def navigate_home(self):
        self.browser.setUrl(QUrl("https://duckduckgo.com/"))

    def navigate_to_url(self):
        q = QUrl(self.urlbar.text())
        if q.scheme() == "":
            q.setScheme("http")
        self.browser.setUrl(q)

    def update_urlbar(self, q):
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)

    def on_download_requested(self, download):
        # Determine the user's Downloads folder
        downloads_folder = QStandardPaths.writableLocation(QStandardPaths.DownloadLocation)
        
        # Set the download path to the Downloads folder
        file_name = download.url().fileName()
        download_path = os.path.join(downloads_folder, file_name)

        # Connect to the download's signals to track progress
        download.finished.connect(self.on_download_finished)
        download.downloadProgress.connect(self.on_download_progress)
        download.setPath(download_path)
        download.accept()

    def on_download_progress(self, received, total):
        # Update the progress bar
        if total > 0:
            progress = int((received / total) * 100)
            self.download_progress.setValue(progress)

    def on_download_finished(self):
        # Once download is finished, reset the progress bar
        self.download_progress.reset()

# creating a PyQt5 application
app = QApplication(sys.argv)

# setting name to the application
app.setApplicationName("timberfart")

# creating a main window object
window = MainWindow()

# loop
app.exec_()
