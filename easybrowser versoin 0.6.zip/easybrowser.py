from PyQt5.QtCore import *
from PyQt5.QtWidgets import *
from PyQt5.QtGui import *
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtPrintSupport import *
import os
import sys

class MainWindow(QMainWindow):

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # Creating a QWebEngineView
        self.browser = QWebEngineView()

        # Set default browser URL
        self.browser.setUrl(QUrl("https://duckduckgo.com/"))

        # Connect signals efficiently
        self._connect_signals()

        # Set browser as central widget
        self.setCentralWidget(self.browser)

        # Status bar
        self.status = QStatusBar()
        self.setStatusBar(self.status)

        # Create the navigation toolbar
        self.create_navigation_toolbar()

        # Show the window
        self.show()

    def _connect_signals(self):
        """Efficiently connect signals."""
        self.browser.page().profile().downloadRequested.connect(self.handle_download)
        self.browser.urlChanged.connect(self.update_urlbar)
        self.browser.loadFinished.connect(self.update_title)

    def create_navigation_toolbar(self):
        """Create and set up navigation toolbar."""
        navtb = QToolBar("Navigation")
        self.addToolBar(navtb)

        # Add back, forward, reload, and home buttons
        self._add_action(navtb, "<--", "Back to previous page", self.browser.back)
        self._add_action(navtb, "-->", "Forward to next page", self.browser.forward)
        self._add_action(navtb, "Reload", "Reload page", self.browser.reload)
        self._add_action(navtb, "Home", "Go home", self.navigate_home)

        # Separator and URL bar
        navtb.addSeparator()
        self.urlbar = QLineEdit()
        self.urlbar.returnPressed.connect(self.navigate_to_url)
        navtb.addWidget(self.urlbar)

        # Stop button
        self._add_action(navtb, "Stop", "Stop loading current page", self.browser.stop)

    def _add_action(self, toolbar, text, status_tip, action_func):
        """Helper method to add actions to the toolbar."""
        action = QAction(text, self)
        action.setStatusTip(status_tip)
        action.triggered.connect(action_func)
        toolbar.addAction(action)

    def update_title(self):
        """Update the title of the window."""
        title = self.browser.page().title()
        self.setWindowTitle(f"{title} - easy browser")

    def navigate_home(self):
        """Navigate to the home page."""
        self.browser.setUrl(QUrl("https://duckduckgo.com/"))

    def navigate_to_url(self):
        """Navigate to the URL from the address bar."""
        url_text = self.urlbar.text().strip()
        if not QUrl(url_text).scheme():
            url_text = f"http://{url_text}"
        self.browser.setUrl(QUrl(url_text))

    def update_urlbar(self, q):
        """Update the URL bar."""
        self.urlbar.setText(q.toString())
        self.urlbar.setCursorPosition(0)

    def handle_download(self, download):
        """Handle file download."""
        suggested_filename = download.suggestedFileName()
        # Set the path for download in a more efficient way
        download.setPath(os.path.join(QStandardPaths.writableLocation(QStandardPaths.DownloadLocation), suggested_filename))
        download.accept()

# Create the PyQt5 application
app = QApplication(sys.argv)
app.setApplicationName("easy browser")

# Create the main window and start the event loop
window = MainWindow()
sys.exit(app.exec_())